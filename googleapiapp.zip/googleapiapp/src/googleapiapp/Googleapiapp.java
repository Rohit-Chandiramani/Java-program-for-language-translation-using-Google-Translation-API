package googleapiapp;

import java.util.*;

import com.google.api.services.translate.Translate;
import com.google.api.services.translate.model.TranslationsListResponse;
import com.google.api.services.translate.model.TranslationsResource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Googleapiapp {
    
    public void calculate()
    {
       String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
       String DB_URL = "jdbc:mysql://localhost:3306/logistics";    
                        
        try{
            Scanner sc=new Scanner(System.in);
            Translate t = new Translate.Builder(
                    com.google.api.client.googleapis.javanet.GoogleNetHttpTransport.newTrustedTransport()
                    , com.google.api.client.json.gson.GsonFactory.getDefaultInstance(), null)                                   
                    //Need to update this to your App-Name
                    .setApplicationName("googleapiapp")                   
                    .build();
            
            String option;
            
            Connection conn = null;
            Statement stmt = null;
            ResultSet rs=null;
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL,"root","R30101997c");
            stmt=conn.createStatement();
            String query="select * from language
            rs=stmt.executeQuery(query);
            
            do
            {
                
                System.out.println("Enter the string to be translated ");
                String input=sc.nextLine();
                
                System.out.println("Entry country code ");
                String code=sc.nextLine();
                
                
                Translate.Translations.List list = t.new Translations().list(
                        Arrays.asList(input),code);
                list.setKey("Add your key here");
                TranslationsListResponse response = list.execute();
                for(TranslationsResource tr : response.getTranslations()) {
                    System.out.println(tr.getTranslatedText());
                }
                
                System.out.println("Enter Y to continue");
                option=sc.nextLine();
            }while(option.equalsIgnoreCase("Y"));
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Googleapiapp.class.getName()).log(Level.SEVERE, null, ex);
        } 
         catch (Exception e) {
            e.printStackTrace();
        }
    }
        public static void main(String[]args) {
        
        
}
}